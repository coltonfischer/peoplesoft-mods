1. Import PSM_ALLIANCE_2017 into App Designer.
2. Build the project.
3. Map the related content services to desired CREFs.

Important Notes:
1. Put the provided psGAuth.jar file in $PS_HOME/class directory if you want to use the MFA service.  An app server restart will be needed.
2. For the user search logging service, you should change the URL that the search values are sent to.