package com.peoplesoft.pt.custom;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RedirectFilter implements Filter
{
    private FilterConfig filterConfig = null;

    public void init(FilterConfig filterConfig) throws ServletException
    {
        this.filterConfig = filterConfig;
    }

    public void destroy()
    {
        filterConfig = null;
    }

    public void doFilter(
            ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException
    {
		
		HttpServletRequest req = (HttpServletRequest) request;
		
		// Check for the token
		Cookie[] cookie_jar = req.getCookies();
		boolean Redirect = true;
		if (cookie_jar != null)
		{
			for (int i =0; i< cookie_jar.length; i++)
			{
				Cookie aCookie = cookie_jar[i];
				if(aCookie.getName().equals(filterConfig.getInitParameter("TokenName")))
				{
					// You need to check if the actual value of the token is valid.
					// This will involve running the same encryption or hashing
					// algorithm that the authenticator ran to create the token's
					// value.  For demo purposes, I will not redirect a user as
					// long as they present a correctly named token.
					Redirect = false;
				}
			}
		}
		
		// Redirect the user to the authenticator if they do not have a valid token
		if(Redirect){
			// System.out.println("Unauthorized access request");
			// Capture the url that the user was trying to access so that
			// the authenticator can redirect them back to the resource
			// after successful authentication.
			String uri = req.getRequestURI();
			String URLwQueryParam = req.getRequestURL().append('?').append(req.getQueryString()).toString();
			HttpServletResponse res = (HttpServletResponse) response;
			// Set the url below to the authenticator's login
			res.sendRedirect(filterConfig.getInitParameter("AuthenticatorURL") + "?URL=" + URLwQueryParam);
		}
		else{
		// send the message down the chain
		chain.doFilter(request, response);
		}	
    }
}