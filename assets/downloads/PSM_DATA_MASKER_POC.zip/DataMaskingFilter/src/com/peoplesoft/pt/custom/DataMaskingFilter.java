package com.peoplesoft.pt.custom;

import javax.servlet.http.*;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.Filter;
import javax.servlet.ServletResponse;
import javax.servlet.ServletOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.ByteArrayOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataMaskingFilter implements Filter
{
    private FilterConfig filterConfig = null;

    private static class ByteArrayServletStream extends ServletOutputStream
    {
        ByteArrayOutputStream baos;

        ByteArrayServletStream(ByteArrayOutputStream baos)
        {
            this.baos = baos;
        }

        public void write(int param) throws IOException
        {
            baos.write(param);
        }
    }

    private static class ByteArrayPrintWriter
    {

        private ByteArrayOutputStream baos = new ByteArrayOutputStream();

        private PrintWriter pw = new PrintWriter(baos);

        private ServletOutputStream sos = new ByteArrayServletStream(baos);

        public PrintWriter getWriter()
        {
            return pw;
        }

        public ServletOutputStream getStream()
        {
            return sos;
        }

        byte[] toByteArray()
        {
            return baos.toByteArray();
        }
    }

    public class CharResponseWrapper extends HttpServletResponseWrapper
    {
        private ByteArrayPrintWriter output;
        private boolean usingWriter;

        public CharResponseWrapper(HttpServletResponse response)
        {
            super(response);
            usingWriter = false;
            output = new ByteArrayPrintWriter();
        }

        public byte[] getByteArray()
        {
            return output.toByteArray();
        }

        @Override
        public ServletOutputStream getOutputStream() throws IOException
        {
            // will error out, if in use
            if (usingWriter) {
                super.getOutputStream();
            }
            usingWriter = true;
            return output.getStream();
        }

        @Override
        public PrintWriter getWriter() throws IOException
        {
            // will error out, if in use
            if (usingWriter) {
                super.getWriter();
            }
            usingWriter = true;
            return output.getWriter();
        }

        public String toString()
        {
            return output.toString();
        }
    }

    public void init(FilterConfig filterConfig) throws ServletException
    {
        this.filterConfig = filterConfig;
    }

    public void destroy()
    {
        filterConfig = null;
    }

    public void doFilter(
            ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException
    {
		
	HttpServletRequest req = (HttpServletRequest) request;
	
	// Check for cookie that signifies a mask is not needed
	// You might want to conditionally mask SSN based on the user's location or if they've performed 2FA for the session.
	Cookie[] cookie_jar = req.getCookies();
	boolean Mask = true;
	if (cookie_jar != null)
	{
		for (int i =0; i< cookie_jar.length; i++)
		{
			Cookie aCookie = cookie_jar[i];
			if(aCookie.getName().equals("YOUR_COOKIE_NAME"))
			{
				/* Validate Cookie's Value Here */
				Mask = false;
			}
		}
	}
	
    CharResponseWrapper wrappedResponse = new CharResponseWrapper((HttpServletResponse)response);
    chain.doFilter(request, wrappedResponse);
	
    byte[] bytes = wrappedResponse.getByteArray(); 	
	if (Mask)
	{
		String out = new String(bytes);
		String MaskedSSN = "***-**-****";
		String Disabled = " disabled ";
		
		Pattern pattx = Pattern.compile("(\")((\\d{3})(-?)(\\d{2})(-?)(\\d{4}))(\")");
		Matcher mx = pattx.matcher(out);
		StringBuffer sbx = new StringBuffer(out.length());
		while (mx.find()) 
		{
			mx.appendReplacement(sbx, mx.group(1) + MaskedSSN + mx.group(8) + Disabled);
		}
		mx.appendTail(sbx);
		out = sbx.toString();
		
		Pattern patt = Pattern.compile("(>)((\\d{3})(-?)(\\d{2})(-?)(\\d{4}))(<)");
		Matcher m = patt.matcher(out);
		StringBuffer sb = new StringBuffer(out.length());
		while (m.find()) 
		{
			m.appendReplacement(sb,Disabled + m.group(1) + MaskedSSN + m.group(8));
		}
		m.appendTail(sb);
		out = sb.toString();
		
		Pattern patty = Pattern.compile("(\\[)((\\d{3})(-?)(\\d{2})(-?)(\\d{4}))(\\])");
		Matcher my = patty.matcher(out);
		StringBuffer sby = new StringBuffer(out.length());
		while (my.find()) 
		{
			my.appendReplacement(sby,my.group(1) + MaskedSSN + my.group(8));
		}
		my.appendTail(sby);
		out = sby.toString();
		
		response.setContentLength(out.length());
		response.getOutputStream().write(out.getBytes());		
	}
    else 
	{
        response.getOutputStream().write(bytes);
    }
    }
}