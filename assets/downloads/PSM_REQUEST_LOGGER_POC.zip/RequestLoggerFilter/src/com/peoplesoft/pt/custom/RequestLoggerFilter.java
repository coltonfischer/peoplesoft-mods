package com.peoplesoft.pt.custom;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequestWrapper;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import org.apache.commons.io.IOUtils;
import javax.servlet.ServletInputStream;

import java.util.Map;

//import java.net.URLEncoder;

public class RequestLoggerFilter implements Filter
{
    private FilterConfig filterConfig = null;

    public void init(FilterConfig filterConfig) throws ServletException
    {
        this.filterConfig = filterConfig;
    }

    public void destroy()
    {
        filterConfig = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
    {
		//HttpServletRequest req = (HttpServletRequest) request;
		ResettableStreamHttpServletRequest req = new ResettableStreamHttpServletRequest((HttpServletRequest) request);
		
		// string to hold csv output
		String Output = "";
		// get the requested uri
		String uri = req.getRequestURI();
		Output += uri;
		
		// get the content types that need to be logged
		String ContentTypeParams = String.valueOf(filterConfig.getInitParameter("ContentTypes"));
		// get the attributes that need to be logged
		String AttributeParams = String.valueOf(filterConfig.getInitParameter("Attributes"));
		// get the LogBody param
		//String AttributeParams = String.valueOf(filterConfig.getInitParameter("LogBody"));
		Boolean Log;
		
		// if the ContentTypes parameter is a "*" then everything will be logged
		if(ContentTypeParams.equals("*"))
		{
			Log = true;	
		}
		else
		{
			Log = false;
			List<String> ContentTypesToLog;
			ContentTypesToLog = Arrays.asList(ContentTypeParams.split("\\s*,\\s*"));
			// check if the uri contains one of the content types specified
			for (int z = 0; z < ContentTypesToLog.size(); z++) 
			{	
				Pattern patternx = Pattern.compile("\\/" + ContentTypesToLog.get(z) + "\\/", Pattern.CASE_INSENSITIVE);
				Matcher matcherx = patternx.matcher(uri);
				if (matcherx.find())
				{
					Log = true;
					break;
				}	
			
			}
		}
		
		if(Log)
		{
			// get the session id
			String SessionID = req.getSession().getId();
			// get the datetime
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Calendar calobj = Calendar.getInstance();
			String DateTime = df.format(calobj.getTime());
		
			// write to file
			//String Filename = "PSM_REQUEST_LOG";
			String Filename = String.valueOf(filterConfig.getInitParameter("FileName"));
			// MM_DD_YY will be appended to the filename
			DateFormat dfx = new SimpleDateFormat("MM_dd_yy");
			Calendar calobjx = Calendar.getInstance();
			String Date = dfx.format(calobjx.getTime());
			File file = new File(Filename + "_" + Date + ".csv");
	
			// if file doesnt exists, then create it
			if (!file.exists()) 
			{
				file.createNewFile();
			}
			// begin additional attribute logging
			String Attr = "";
			if(AttributeParams != null && !AttributeParams.isEmpty())
			{
				// fetch additional attributes to log
				HttpSession session = req.getSession(true);
				Boolean AllAttr = false;
				
				if(AttributeParams.equals("*"))
				{
					AllAttr = true;
				}
				
				List<String> AttributesToLog;
				AttributesToLog = Arrays.asList(AttributeParams.split("\\s*,\\s*"));
				
				Enumeration e = session.getAttributeNames();
				
				while (e.hasMoreElements())
				{
					String mykey = (String)e.nextElement();
					
					if(AllAttr)
					{
						Attr = Attr.concat("," + mykey + "=" + session.getAttribute(mykey).toString().replaceAll("\\r\\n|[\\r\\n]|,", " "));
					}
					else
					{
						for (int z = 0; z < AttributesToLog.size(); z++) 
						{
							if (mykey.equals(AttributesToLog.get(z)))
							{
								Attr = Attr.concat("," + mykey + "=" +  session.getAttribute(mykey).toString().replaceAll("\\r\\n|[\\r\\n]|,", " "));
								break;
							}
						}
					}	
				}
				Output += Attr;
			}
			// end additional attribute logging
			// begin logging query strings
			String QueryStr = "";
			if(String.valueOf(filterConfig.getInitParameter("LogQueryStr")).equals("1"))
			{
				QueryStr = "," + req.getQueryString();
				Output += QueryStr;
			}
			// end logging query strings
			// begin logging body
			String body = "";
			if(String.valueOf(filterConfig.getInitParameter("LogBody")).equals("1"))
			{
				body = "," + IOUtils.toString(req.getReader());
				Output += body;
				req.resetInputStream();
			}
			// end logging body
			// write uri, datetime, and additional attributes to file
			FileWriter fw = new FileWriter(file, true);
			BufferedWriter bw = new BufferedWriter(fw);
			//bw.write(uri + "," + QueryStr + "," + DateTime + Attr + "," + body);
			bw.write(DateTime + "," + Output);
			bw.newLine();
			bw.close();
		}
		//req.resetInputStream();
		chain.doFilter(req, response);
		//chain.doFilter(request, response);
    }
	
	// begin extra wrapper classes needed for reading the request body
	private static class ResettableStreamHttpServletRequest extends HttpServletRequestWrapper 
	{

		private byte[] rawData;
		private HttpServletRequest request;
		private ResettableServletInputStream servletStream;

		public ResettableStreamHttpServletRequest(HttpServletRequest request) {
			super(request);
			this.request = request;
			this.servletStream = new ResettableServletInputStream();
		}


		public void resetInputStream() {
			servletStream.stream = new ByteArrayInputStream(rawData);
		}

		@Override
		public ServletInputStream getInputStream() throws IOException {
			if (rawData == null) {
				rawData = IOUtils.toByteArray(this.request.getReader());
				servletStream.stream = new ByteArrayInputStream(rawData);
			}
			return servletStream;
		}

		@Override
		public BufferedReader getReader() throws IOException {
			if (rawData == null) {
				rawData = IOUtils.toByteArray(this.request.getReader());
				servletStream.stream = new ByteArrayInputStream(rawData);
			}
			return new BufferedReader(new InputStreamReader(servletStream));
		}
		

		private class ResettableServletInputStream extends ServletInputStream {

			private InputStream stream;

			@Override
			public int read() throws IOException {
				return stream.read();
			}
		}
	}
}