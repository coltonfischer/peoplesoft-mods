package com.peoplesoft.pt.custom;

import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;
import java.util.Enumeration;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class CacheManager extends HttpServlet {
	
	private static Map<String, String> initParamsMap = new HashMap<String, String>();
	private static Map<String, String> cacheMAP = Collections.synchronizedMap(new HashMap<String, String>());
	
	public void init() throws ServletException {
		Enumeration<String> initParams = getServletConfig().getInitParameterNames();
		System.out.println(initParams + " initParams");
		while (initParams.hasMoreElements()) {
			String initParamName = initParams.nextElement();
			System.out.println(initParamName + " initParamName");
			String initParamValue = getServletConfig().getInitParameter(initParamName);
			initParamsMap.put(initParamName, initParamValue);
			setCache(initParamName);
		}
    }
	
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
        String uri = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + "/CacheManager";
		String status = "Cache Manager API:</br></br>Update the data source for a data type:</br>" + uri + "?dataType=My_Data_Type&data=My_Updated_Data</br></br>View the data source for a data type:</br>" + uri + "?dataType=My_Data_Type&getDataSource</br></br>View cached contents for a data type:</br>" + uri + "?dataType=My_Data_Type&getCache</br></br>Load the data source into cache for a data type:</br>" + uri + "?dataType=My_Data_Type&setCache";

		if((request.getParameter("dataType") == null)?false:true){
			String dataType = request.getParameter("dataType");
			status = "dataType = " + dataType + " - dataSource = " + initParamsMap.get(dataType) + "</br></br>";
			if((request.getParameter("data") == null)?false:true){
				String data = request.getParameter("data");
				setDataSource(dataType,data);
				status = status + "Data Source Updated</br></br>";
			}
			if((request.getParameter("getDataSource") == null)?false:true){
				status = status + "Data Source Contents:</br>" + getDataSource(dataType) + "</br></br>";
			}
			if((request.getParameter("setCache") == null)?false:true){
				setCache(dataType);
				status = status + "Cache Updated</br></br>";
			}
			if((request.getParameter("getCache") == null)?false:true){
				status = status + "Cache Contents:</br>" + getCache(dataType) + "</br></br>";
			}
		}
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter pw = response.getWriter();
		pw.write(status);
    }

    @Override
	public void destroy() {
		deleteCache();
	}

	public static String getDataSource(String dataType)
	{
		try{
			File file = new File(initParamsMap.get(dataType));
			String content = new Scanner(file).useDelimiter("\\Z").next();
			return content;
		}catch(Exception e){
			e.printStackTrace();
			return "Error getting data source";
		}
	}

	public void setDataSource(String dataType, String data)
	{
		try{
			FileWriter filewriter = new FileWriter(initParamsMap.get(dataType), false);
			filewriter.write(data);
			filewriter.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static String getCache(String dataType)
	{
		return cacheMAP.get(dataType);
	}

	public void setCache(String dataType)
	{
		cacheMAP.put(dataType, getDataSource(dataType));
	}

	public void deleteCache() {
		cacheMAP.clear();
	}
}