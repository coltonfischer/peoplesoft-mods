package com.peoplesoft.pt.custom;

import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import javax.servlet.ServletOutputStream;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.servlet.http.HttpServletResponse;

public class CompressionFilter implements Filter
{
    private FilterConfig filterConfig = null;
	
	private static class ByteArrayServletStream extends ServletOutputStream
    {
        ByteArrayOutputStream baos;

        ByteArrayServletStream(ByteArrayOutputStream baos)
        {
            this.baos = baos;
        }

        public void write(int param) throws IOException
        {
            baos.write(param);
        }
    }

    private static class ByteArrayPrintWriter
    {

        private ByteArrayOutputStream baos = new ByteArrayOutputStream();

        private PrintWriter pw = new PrintWriter(baos);

        private ServletOutputStream sos = new ByteArrayServletStream(baos);

        public PrintWriter getWriter()
        {
            return pw;
        }

        public ServletOutputStream getStream()
        {
            return sos;
        }

        byte[] toByteArray()
        {
            return baos.toByteArray();
        }
    }

    public class CharResponseWrapper extends HttpServletResponseWrapper
    {
        private ByteArrayPrintWriter output;
        private boolean usingWriter;

        public CharResponseWrapper(HttpServletResponse response)
        {
            super(response);
            usingWriter = false;
            output = new ByteArrayPrintWriter();
        }

        public byte[] getByteArray()
        {
            return output.toByteArray();
        }

        @Override
        public ServletOutputStream getOutputStream() throws IOException
        {
            // will error out, if in use
            if (usingWriter) {
                super.getOutputStream();
            }
            usingWriter = true;
            return output.getStream();
        }

        @Override
        public PrintWriter getWriter() throws IOException
        {
            // will error out, if in use
            if (usingWriter) {
                super.getWriter();
            }
            usingWriter = true;
            return output.getWriter();
        }

        public String toString()
        {
            return output.toString();
        }
    }
	
	public class RequestWrapper extends HttpServletRequestWrapper
    {
		private Set<String> headerNameSet;
		
        public RequestWrapper(HttpServletRequest request)
        {
            super(request);
        }
		
		@Override
		public Enumeration<String> getHeaderNames() {
			if (headerNameSet == null) {
				// first time this method is called, cache the wrapped request's header names:
				headerNameSet = new HashSet<>();
				Enumeration<String> wrappedHeaderNames = super.getHeaderNames();
				while (wrappedHeaderNames.hasMoreElements()) {
					String headerName = wrappedHeaderNames.nextElement();
					if (!"Accept-Encoding".equalsIgnoreCase(headerName)) {
						headerNameSet.add(headerName);
					}
				}
			}
			return Collections.enumeration(headerNameSet);
		}

		@Override
		public Enumeration<String> getHeaders(String name) {
			if ("Accept-Encoding".equalsIgnoreCase(name)) {
				return Collections.<String>emptyEnumeration();
			}
			return super.getHeaders(name);
		}

		@Override
		public String getHeader(String name) {
			if ("Accept-Encoding".equalsIgnoreCase(name)) {
				return null;
			}
			return super.getHeader(name);
		}	
    }

    public void init(FilterConfig filterConfig) throws ServletException
    {
        this.filterConfig = filterConfig;
    }

    public void destroy()
    {
        filterConfig = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
    {
		RequestWrapper wrappedRequest = new RequestWrapper((HttpServletRequest) request);
		CharResponseWrapper wrappedResponse = new CharResponseWrapper((HttpServletResponse)response);
		chain.doFilter(wrappedRequest, wrappedResponse);
		
		byte[] bytes = wrappedResponse.getByteArray(); 	
		String out = new String(bytes);

		//Evaluate compression type and compress accordingly
		HttpServletRequest req = (HttpServletRequest) request;
		String acceptEncoding = req.getHeader("Accept-Encoding");

		if (acceptEncoding.indexOf("gzip") > -1) {
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			GZIPOutputStream gzip = new GZIPOutputStream(outputStream);
			gzip.write(out.getBytes());
			gzip.close();
			wrappedResponse.setHeader("Content-Encoding", "gzip");
			response.setContentLength(outputStream.toByteArray().length);
			response.getOutputStream().write(outputStream.toByteArray());
		} 
		else {
			response.setContentLength(out.getBytes().length);
			response.getOutputStream().write(out.getBytes());
		}
		
    }
}